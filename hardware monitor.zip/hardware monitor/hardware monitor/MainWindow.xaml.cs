﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Management;
using Microsoft.Win32;

namespace hardware_monitor
{
    public partial class MainWindow : Window
    {
        System.Windows.Threading.DispatcherTimer field = new System.Windows.Threading.DispatcherTimer();

        public MainWindow()
        {
            InitializeComponent();
            field.Tick += new EventHandler(@event);
            field.Interval = new TimeSpan(0, 0, 1);
            field.Start();
        }

        private void @event(object sender, EventArgs e)
        {
            cpu();
            gpu();
            mem();
            board();
        }
        private void board()
        {
            System.Management.ManagementClass vmi = new System.Management.ManagementClass("Win32_BaseBoard");
            var valtozik = vmi.GetInstances();

            foreach (var item in valtozik)
            {
                string boardModel = item["Product"].ToString();
                string boardManufact = item["Manufacturer"].ToString();

                petiBoardName.Text = "board type:" + "  " + boardModel.ToString();
                petiBoardMan.Text = "board:" + "  " + boardManufact.ToString();
            }
        }
        private void cpu()
        {
            System.Management.ManagementClass vmi = new System.Management.ManagementClass("Win32_Processor");
            var valtozik = vmi.GetInstances();

            foreach (var item in valtozik)
            {
                string cpuName = item["Name"].ToString();
                int cpuSpeed = Convert.ToInt32(item["CurrentClockSpeed"]);
                string cpuStatus = item["Status"].ToString();
                int cpucore = Convert.ToInt32(item["ThreadCount"]);

               peticpuName.Text ="cpuname:"+ " " + cpuName.ToString();
               peticpuSpeed.Text ="cpuspeed:" + "    "+  cpuSpeed.ToString() + " " + "MHz";
               peticpuStatus.Text = "cpustatus:" + " " + cpuStatus.ToString();
               peticpucore.Text ="cpucores:" + "  " + cpucore.ToString();
            }
        }
        private void mem()
        {
            System.Management.ManagementClass vmi = new System.Management.ManagementClass("Win32_PhysicalMemory");
            var valtozik = vmi.GetInstances();

            foreach (var item in valtozik)
            {
                int memSpeed = Convert.ToInt32(item["Speed"]);
 
                petimemSpeed.Text = "mem speed:" + "  " + memSpeed.ToString() + "  " + "MHz";
            }
        }
        private void gpu()
        {
            System.Management.ManagementClass vmi = new System.Management.ManagementClass("Win32_VideoController");
            var valtozik = vmi.GetInstances();

            foreach (var item in valtozik)
            {
                string GpuName = item["Name"].ToString();
                string GpuDriver = item["DriverVersion"].ToString();

               petiGpuName.Text ="gpuname" + "   " + GpuName.ToString();
               petiGpuDriver.Text ="gpudriver:" + "  " + GpuDriver.ToString();
            }
        }

    }

}
